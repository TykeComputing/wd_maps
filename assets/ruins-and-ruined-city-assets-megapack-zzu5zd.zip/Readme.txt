Thank you for your support !


Take a look at all of my asset packs available at best prices in my online shop!
 Including some unique assets and resources you won't find anywhere else :

https://fantasymapassets.com



You can also support me on Patreon and download tons of Patreon exclusive assets here :

https://www.patreon.com/CartographicFantasy

One brand new Wonderdraft asset every two days !


Have a good mapping !










Installation Instructions for Wonderdraft

After you have downloaded the zipped file unzip it into an empty folder.

You will have a new folder: ‘ruins and ruined city assets megapack’. Locate your Wonderdraft assets folder.

Copy and paste ‘ruins and ruined city assets megapack’ folder into your Wonderdraft assets folder.



Instructions for use with Photoshop or Gimp or any other image editing software

You can use the included PNG images with these software programs. 

For images labeled as 'normal color,' you can use them as-is in all of your image software. 

For images labeled as 'sample color,' if you want to create a transparent background and only keep the outlines so you can add your own colors, it's best to put the layer with the image(s) in 'multiply' mode. This will make the white color completely transparent, allowing you to keep only the black lines.

For images labeled as 'custom color,' you can choose your own colors by changing the hue of each of the three primary colors separately.









