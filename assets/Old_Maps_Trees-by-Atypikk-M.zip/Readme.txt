Thank you for your support !


Take a look at all of my asset packs available at best prices in my online shop!
 Including some unique assets and resources you won't find anywhere else :

https://fantasymapassets.com



You can also support me on Patreon and download tons of Patreon exclusive assets here :

https://www.patreon.com/CartographicFantasy

One brand new Wonderdraft asset every two days !


Have a good mapping !





Installation Instructions for Wonderdraft

After you have downloaded the zipped file unzip it into an empty folder.

You will have a new folder: “Old_Maps_Trees by Atypikk M”. Locate your Wonderdraft assets folder.

Copy and paste “Old_Maps_Trees by Atypikk M” folder into your Wonderdraft assets folder.


Instructions for use with Photoshop or Gimp or any other image editing software

You can use the included PNG images with these software programs. If you want to create a transparent background and only keep the outlines so you can add your own colors, it's best to put the layer with the image(s) in 'multiply' mode. This will make the white color completely transparent, allowing you to keep only the black lines.





